import 'package:flutter/material.dart';
import 'package:tgchart/storage_category.dart';
import 'package:tgchart/storage_utils.dart';
import 'package:tgchart/widgets/storage_categories_card.dart';
import 'package:tgchart/widgets/storage_usage_chart.dart';
import 'package:tgchart/widgets/storage_usage_header.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final Color bgBlue = const Color(0xFF4292ED);
  final Color bgTeal = const Color(0xFF4FC8AE);
  final Color bgOrange = const Color(0xFFF18A37);
  final Color bgGreen = const Color(0xFF33C94B);
  final Color bgYellow = const Color(0xFFF2A93B);
  final Color scaffoldBg = const Color(0xFF17202A);
  final Color cardBg = const Color(0xFF1E2B38);

  late List<StorageCategory> categories;

  @override
  void initState() {
    super.initState();
    categories = [
      StorageCategory(name: 'Videos', value: 260.4, color: bgBlue),
      StorageCategory(name: 'Profile Photos', value: 188.4, color: bgTeal),
      StorageCategory(name: 'Stickers & Emoji', value: 112.1, color: bgOrange),
      StorageCategory(name: 'Documents', value: 74.3, color: bgGreen),
      StorageCategory(name: 'Other', value: 140.6, color: bgYellow),
    ];
  }

  void toggleCategory(int index) {
    setState(() {
      categories[index].isSelected = !categories[index].isSelected;
    });
  }

  @override
  Widget build(BuildContext context) {
    double totalSelected = categories
        .where((c) => c.isSelected)
        .fold(0.0, (sum, c) => sum + c.value);

    return Scaffold(
      backgroundColor: scaffoldBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 10),
              StorageUsageChart(categories: categories),
              const SizedBox(height: 24),
              StorageUsageHeader(progressColor: bgBlue),
              const SizedBox(height: 30),
              StorageCategoriesCard(
                categories: categories,
                onToggle: (index) =>
                    () => toggleCategory(index),
                backgroundColor: cardBg,
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2EA5FF),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: totalSelected > 0 ? () {} : null,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Text(
                      'Clear Cache ${totalSelected > 0 ? StorageUtils.format(totalSelected) : ''}',
                      key: ValueKey(totalSelected),
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
