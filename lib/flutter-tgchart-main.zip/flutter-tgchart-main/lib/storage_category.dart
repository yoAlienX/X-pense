import 'package:flutter/material.dart';

class StorageCategory {
  final String name;
  final double value;
  final Color color;
  bool isSelected;

  StorageCategory({
    required this.name,
    required this.value,
    required this.color,
    this.isSelected = true,
  });
}
