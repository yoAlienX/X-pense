class StorageUtils {
  static String formatValue(double mb) {
    if (mb >= 1024) {
      return (mb / 1024).toStringAsFixed(1);
    } else if (mb >= 1) {
      return (mb == mb.roundToDouble()
          ? mb.toInt().toString()
          : mb.toStringAsFixed(1));
    } else {
      final double kb = mb * 1024;
      return (kb == kb.roundToDouble()
          ? kb.toInt().toString()
          : kb.toStringAsFixed(1));
    }
  }

  static String formatUnit(double mb) {
    if (mb >= 1024) return 'GB';
    if (mb >= 1) return 'MB';
    return 'KB';
  }

  static String format(double mb) {
    if (mb == 0) return '0 MB';
    return '${formatValue(mb)} ${formatUnit(mb)}';
  }
}
