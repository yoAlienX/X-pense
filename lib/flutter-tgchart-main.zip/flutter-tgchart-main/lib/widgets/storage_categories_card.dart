import 'package:flutter/material.dart';
import 'package:tgchart/storage_category.dart';
import 'package:tgchart/storage_utils.dart';

class StorageCategoriesCard extends StatelessWidget {
  final List<StorageCategory> categories;
  final VoidCallback Function(int index) onToggle;
  final Color backgroundColor;

  const StorageCategoriesCard({
    super.key,
    required this.categories,
    required this.onToggle,
    required this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    final double total = categories.fold(
      0.0,
      (sum, category) => sum + category.value,
    );

    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: .generate(categories.length, (index) {
          final StorageCategory category = categories[index];
          final bool isLast = index == categories.length - 1;

          return Column(
            children: [
              StorageCategoryTile(
                category: category,
                percentage: total == 0
                    ? 0
                    : (category.value / total * 100).round(),
                onTap: onToggle(index),
              ),
              if (!isLast)
                Divider(
                  height: 1,
                  thickness: 1,
                  color: Colors.black.withValues(alpha: 0.2),
                  indent: 60,
                ),
            ],
          );
        }),
      ),
    );
  }
}

class StorageCategoryTile extends StatelessWidget {
  final StorageCategory category;
  final int percentage;
  final VoidCallback onTap;

  const StorageCategoryTile({
    super.key,
    required this.category,
    required this.percentage,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: category.isSelected ? category.color : Colors.transparent,
            border: Border.all(
              color: category.isSelected
                  ? category.color
                  : Colors.white.withValues(alpha: 0.3),
              width: 2,
            ),
          ),
          child: category.isSelected
              ? const Icon(Icons.check, size: 16, color: Colors.white)
              : null,
        ),
      ),
      title: Row(
        children: [
          Text(
            category.name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            '$percentage%',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.8),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
      trailing: Text(
        StorageUtils.format(category.value),
        style: const TextStyle(
          color: Color(0xFF6CAFF5),
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
    );
  }
}
