import 'package:flutter/material.dart';
import 'package:tgchart/storage_category.dart';
import 'package:tgchart/storage_utils.dart';
import 'package:tgchart/widgets/animated_pie_chart.dart';

class StorageUsageChart extends StatelessWidget {
  final List<StorageCategory> categories;

  const StorageUsageChart({super.key, required this.categories});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      child: AnimatedPieChart(
        segments: categories
            .map(
              (category) => PieChartSegment(
                label: category.name,
                value: category.value,
                color: category.color,
                isSelected: category.isSelected,
              ),
            )
            .toList(),
        centerBuilder: (context, total) {
          return SizedBox(
            width: 92,
            child: Column(
              mainAxisSize: .min,
              children: [
                FittedBox(
                  fit: .scaleDown,
                  child: Text(
                    StorageUtils.formatValue(total),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: .bold,
                      height: 1,
                    ),
                    textAlign: .center,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  StorageUtils.formatUnit(total),
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.5),
                    fontSize: 13,
                  ),
                  textAlign: .center,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
