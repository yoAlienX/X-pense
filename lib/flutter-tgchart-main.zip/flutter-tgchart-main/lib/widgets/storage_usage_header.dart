import 'package:flutter/material.dart';

class StorageUsageHeader extends StatelessWidget {
  final Color progressColor;

  const StorageUsageHeader({super.key, required this.progressColor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text(
          'Storage Usage',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: .bold,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Telegram uses 1% of your device storage.',
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.5),
            fontSize: 15,
          ),
        ),
        const SizedBox(height: 20),
        Container(
          height: 4,
          width: 180,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.1),
            borderRadius: .circular(2),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                decoration: BoxDecoration(
                  color: progressColor,
                  borderRadius: .circular(2),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
